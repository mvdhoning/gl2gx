/*---------------------------------------------------------------------------------

	OpenGL Tempate for Wii

---------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include <unistd.h>

#ifdef __PPC__
#include <gccore.h>
#include <wiiuse/wpad.h>
#else
#include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#ifdef __WIN32__
#include <GL/glaux.h>
#endif

#ifdef __PPC__
#include "cratetex.h"
#include "cratetex_bin.h"
#endif

GLfloat	xrot = 0.0f;				// X Rotation
GLfloat	yrot = 0.0f;				// Y Rotation
GLfloat xspeed = 0.2f;				// X Rotation Speed
GLfloat yspeed = 0.2f;				// Y Rotation Speed
GLfloat	z=-5.0f;			// Depth Into The Screen

GLfloat LightAmbient[]=		{ 0.0f, 0.0f, 1.0f, 1.0f };
GLfloat LightDiffuse[]=		{ 1.0f, 1.0f, 1.0f, 1.0f };

GLfloat LightPosition[]=	{ 0.0f, 0.0f, 2.0f, 1.0f }; 

	GLfloat ambi[]= { 0.0f, 0.0f, 1.0f, 1.0f };				 // Diffuse Light Values ( NEW )
	GLfloat white[]= { 1.0f, 1.0f, 1.0f, 1.0f };				 // Diffuse Light Values ( NEW )
	GLfloat emis[]= { 0.1f, 0.1f, 0.1f, 1.0f };				 // Diffuse Light Values ( NEW )
	
    GLfloat spec[]= { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat shin= 5.0f;

GLfloat globambi[]= { 0.1f, 0.1f, 1.0f, 1.0f };
  GLfloat no_mat[]= { 0.0f, 0.0f, 0.0f, 1.0f };
  
  GLfloat direction[]={ 0.0f, 0.0f, -1.0f, 1.0};


GLuint	texture[3];			// Storage For 3 Textures

#ifdef __WIN32__
AUX_RGBImageRec *LoadBMP(char *Filename)				// Loads A Bitmap Image
{
	FILE *File=NULL;									// File Handle

	if (!Filename)										// Make Sure A Filename Was Given
	{
		return NULL;									// If Not Return NULL
	}

	File=fopen(Filename,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		return auxDIBImageLoad(Filename);				// Load The Bitmap And Return A Pointer
	}

	return NULL;										// If Load Failed Return NULL
}
#endif

int LoadGLTextures()									// Load Bitmaps And Convert To Textures
{

	int Status=FALSE;									// Status Indicator

#ifdef __PPC__
    
	// load texture
	glGenTextures(1, &texture[0]);					// Create one Texture
	DCFlushRange((void*)cratetex_bin,cratetex_bin_size); //loadtexture procedure
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, cratetex.width, cratetex.height, 0, GL_RGB, GL_UNSIGNED_BYTE, (void*)cratetex_bin);
	glEnable(GL_TEXTURE_2D);						// Enable Texture Mapping ( NEW )
	
    Status=TRUE;									// Set The Status To TRUE
#endif

#ifdef __WIN32__    

	AUX_RGBImageRec *TextureImage[1];					// Create Storage Space For The Texture

	memset(TextureImage,0,sizeof(void *)*1);           	// Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[0]=LoadBMP("DataWin32/Crate.bmp"))
	{
		Status=TRUE;									// Set The Status To TRUE

		glGenTextures(1, &texture[0]);					// Create Three Textures

		// Create Nearest Filtered Texture
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);		
	}
	
	if (TextureImage[0])								// If Texture Exists
	{
		if (TextureImage[0]->data)						// If Texture Image Exists
		{
			free(TextureImage[0]->data);// Free The Texture Image Memory will not compile in dev
		}

		free(TextureImage[0]);							// Free The Image Structure
	}
#endif

	return Status;										// Return The Status
}


// this is where you set up opengl to your needs (called at startup)
int InitGLScene(){

	// setup our camera at the origin
	// looking down the -z axis with y up
	//gluLookAt(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F);

#ifdef __WIN32__ 
    glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
#endif 
 
	// setup our projection matrix
	// this creates a perspective matrix with a view angle of 90,
	// and aspect ratio based on the display resolution
    int w = glutGet(GLUT_SCREEN_WIDTH);
    int h = glutGet(GLUT_SCREEN_HEIGHT);
	gluPerspective(65.0f, (GLfloat) w/(GLfloat) h, 1.0f, 20.0f);

	// initialize the window size ( for glut )
	glutInitWindowSize(glutGet(GLUT_SCREEN_WIDTH), glutGet(GLUT_SCREEN_HEIGHT));
	
#ifdef __WIN32__
	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
#endif

    if (!LoadGLTextures())								// Jump To Texture Loading Routine
	{
		return FALSE;									// If Texture Didn't Load Return FALSE
	}


	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping
	//glDisable(GL_TEXTURE_2D);
	
    //glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	
    glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	//glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);								// Enable Light One
	glEnable(GL_LIGHTING);		// Enable Lighting
    	
	//set up material
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT , ambi);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, white);

	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emis); //was emis
	
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, spec); //specular material
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shin); //shininess
	
	//set up global ambient light
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globambi);
	
	glLightfv(GL_LIGHT1,GL_SPOT_DIRECTION, direction);
	glLightf(GL_LIGHT1,GL_SPOT_CUTOFF, 30.0f);
	
 //exponent propertie defines the concentration of the light
        //glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 50.0f);
        
        //light attenuation (default values used here : no attenuation with the distance)
        //glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0f);
        //glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.0f);
        //glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.0f);
	
    glLightf( GL_LIGHT0, GL_CONSTANT_ATTENUATION, 0.0f );
    glLightf( GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.0f );
    glLightf( GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.002f );

	
//	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);

	
	return TRUE;										// Initialization Went OK
}

//this is where you draw your opengl scene (called each loop by Display)
int DrawGLScene(){
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
	glLoadIdentity();									// Reset The View
		
	glTranslatef(0.0f,0.0f,z);

	glRotatef(xrot,1.0f,0.0f,0.0f);
	glRotatef(yrot,0.0f,1.0f,0.0f);

	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glBegin(GL_QUADS);
		// Front Face
		glNormal3f( 0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		// Back Face
		glNormal3f( 0.0f, 0.0f,-1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		// Top Face
		glNormal3f( 0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		// Bottom Face
		glNormal3f( 0.0f,-1.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		// Right face
		glNormal3f( 1.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		// Left Face
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
	glEnd();
	
		  

	xrot+=xspeed;
	yrot+=yspeed;
	return TRUE;										// Keep Going
}

// called by glutMainLoop (setup by glutDisplayFunc)
void Display(){

#ifdef __PPC__
	//check if user pressed a button on the wiimote
	WPAD_ScanPads();
	if (WPAD_ButtonsDown(0) & WPAD_BUTTON_HOME) exit(0); //if user pressed home button then quit
	if (WPAD_ButtonsDown(0) & WPAD_BUTTON_1) glEnable(GL_LIGHTING);		// Enable Lighting;
	if (WPAD_ButtonsDown(0) & WPAD_BUTTON_2) glDisable(GL_LIGHTING);		// Disable Lighting;
#endif

	DrawGLScene(); //draw the scene

	// do this stuff after drawing
	glFlush();									
	glutSwapBuffers();

#ifdef __PPC__
	usleep(1); //do some sleep
#endif
}

//---------------------------------------------------------------------------------
int main( int argc, char **argv ){
//---------------------------------------------------------------------------------

	//Initialize Glut
	glutInit(&argc, argv);
	
#ifdef __PPC__	
	//Initialize WiiMote
	WPAD_Init();
#else
    glutInitWindowSize(720,480);
    glutInitWindowPosition(10,10);
#endif

	//Set Opengl to use rbg and doublebuffering
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("");

	//Tell Glut to use Display as its main function
	glutDisplayFunc(Display);
	
	glutIdleFunc(Display);

    //Initialize OpenGL (custom)
	InitGLScene();

	//Enter Glut mainloop
	glutMainLoop();

	return 0;
}

